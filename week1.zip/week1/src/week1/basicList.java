package week1;

import java.util.Scanner;

public class basicList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		int[] num = new int[5];
		
		for(int i = 0; i < 5; i++) {
			System.out.printf("������ �Է��ϼ���:");
			num[i] = scan.nextInt();
		}
		for(int P: num) {
			System.out.println(P);
		}
	}

}
